var classimrcp_1_1geosrv_1_1_polygons =
[
    [ "createNewPolygon", "classimrcp_1_1geosrv_1_1_polygons.html#ab88db58f7744b74d4cc2310f377517d0", null ],
    [ "getPolyBox", "classimrcp_1_1geosrv_1_1_polygons.html#aa90f2aab2d9b0a40571bc1822fa48a74", null ],
    [ "getPolygonPoints", "classimrcp_1_1geosrv_1_1_polygons.html#a2a943bbf555bf1ec9ca8e9749683044f", null ],
    [ "getPolyId", "classimrcp_1_1geosrv_1_1_polygons.html#a3fe1ecaab33ad78a2d15c132b8a70bd8", null ],
    [ "polygonIsInList", "classimrcp_1_1geosrv_1_1_polygons.html#a0f0ec98b74d45101b6e3b4f6f2d5f873", null ],
    [ "reset", "classimrcp_1_1geosrv_1_1_polygons.html#a900f1e00be2e44a19367713231a4a409", null ],
    [ "start", "classimrcp_1_1geosrv_1_1_polygons.html#ae3520d6a0560dd449b1702bc00eba47a", null ]
];