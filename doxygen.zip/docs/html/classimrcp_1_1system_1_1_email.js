var classimrcp_1_1system_1_1_email =
[
    [ "Email", "classimrcp_1_1system_1_1_email.html#a3eab31478c532a0ef7e256a49470da3c", null ],
    [ "m_oTo", "classimrcp_1_1system_1_1_email.html#afff2c40e613fb9f9a28369838d49b8b6", null ],
    [ "m_sBody", "classimrcp_1_1system_1_1_email.html#aec33e58d8a355ff3bf3e0713d704cfc3", null ],
    [ "m_sSubject", "classimrcp_1_1system_1_1_email.html#a5749165d7f92da248ebbe2b1d38ccfea", null ]
];