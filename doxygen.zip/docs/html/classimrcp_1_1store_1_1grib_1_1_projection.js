var classimrcp_1_1store_1_1grib_1_1_projection =
[
    [ "m_nScanningMode", "classimrcp_1_1store_1_1grib_1_1_projection.html#a9f086bb79e6f5b498faa84c01c8cf030", null ],
    [ "m_nTemplate", "classimrcp_1_1store_1_1grib_1_1_projection.html#a8d79dc4fc784d8a1a1564016e37639dc", null ],
    [ "m_nX", "classimrcp_1_1store_1_1grib_1_1_projection.html#a0465e495dd3d8c75bdcbea280fa39ffe", null ],
    [ "m_nY", "classimrcp_1_1store_1_1grib_1_1_projection.html#abda2c81e9b83127c9ec66279302812c0", null ]
];