var classimrcp_1_1geosrv_1_1_seg_snap_info =
[
    [ "SegSnapInfo", "classimrcp_1_1geosrv_1_1_seg_snap_info.html#ae773dc3db93a530f685ac415491669ac", null ],
    [ "SegSnapInfo", "classimrcp_1_1geosrv_1_1_seg_snap_info.html#a0e416d6aacf7b358b12aed9b045772ca", null ],
    [ "compareTo", "classimrcp_1_1geosrv_1_1_seg_snap_info.html#a450625da92417530c2393254284736fe", null ],
    [ "reset", "classimrcp_1_1geosrv_1_1_seg_snap_info.html#a9ace479aea69e830ffa1cfa525059225", null ],
    [ "setValues", "classimrcp_1_1geosrv_1_1_seg_snap_info.html#a216816c981d1f55dfd4a93e39a14072c", null ],
    [ "m_dProjSide", "classimrcp_1_1geosrv_1_1_seg_snap_info.html#ad7d42bcde443bbb3b8869103a19d1765", null ],
    [ "m_nLatIntersect", "classimrcp_1_1geosrv_1_1_seg_snap_info.html#a95a51f231122ee64a5394f9c9714b87b", null ],
    [ "m_nLonIntersect", "classimrcp_1_1geosrv_1_1_seg_snap_info.html#ad04e2c4c7c653f2ab8fd62755b3c7d5d", null ],
    [ "m_nRightHandRule", "classimrcp_1_1geosrv_1_1_seg_snap_info.html#ab623d2592732ab59ede2e40bdfef847a", null ],
    [ "m_nSqDist", "classimrcp_1_1geosrv_1_1_seg_snap_info.html#aa7dacad3f15a06ec78fb795969f52186", null ],
    [ "m_oSeg", "classimrcp_1_1geosrv_1_1_seg_snap_info.html#a9f63f9759a7d80d0b702e308cd6d3dc5", null ]
];