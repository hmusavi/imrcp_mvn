var classimrcp_1_1store_1_1_k_c_scout_incidents_csv =
[
    [ "KCScoutIncidentsCsv", "classimrcp_1_1store_1_1_k_c_scout_incidents_csv.html#a460d4e8eee642183648874010257caee", null ],
    [ "load", "classimrcp_1_1store_1_1_k_c_scout_incidents_csv.html#a5da5d678cacabefef7d6554e6556c2be", null ]
];